RUNNING FROM BEARS — Batocera v10 (Pi 4 / aarch64) (Pi 4 / aarch64)
============================================================

INSTALL (pick one)
------------------
A) Over SSH (easiest since you have WiFi + SSH):
     curl -L -o /tmp/rfb.zip https://runningfrombears.ngrok.app/rfb_batocera_v8.zip
     cd /userdata/roms/ports && unzip -o /tmp/rfb.zip
   Then: EmulationStation menu -> GAMES SETTINGS -> UPDATE GAMELISTS
   (or just reboot). Two games appear under PORTS.

B) From another computer: open \\BATOCERA\share, copy the zip contents
   into roms/ports/ (you should end up with the two .sh files in ports/
   and a ports/rfb/ folder), then update gamelists.

CONTROLS (your panel)
---------------------
  Stick        move  (up a tree: look around)
  Button A     jump logs
  Button B     throw pinecone
  Button X     climb / descend tree
  Button Y     hold to RUN (watch the WIND meter)
  Start        start game / pause
  Select       wireframe: toggle steering mode | classic: mute

THE SCREEN IS VERTICAL — READ THIS
----------------------------------
The launcher runs with --rot90 (game renders portrait, rotated onto the
panel). If the picture is upside down, edit the .sh and change --rot90
to --rot270. If Batocera itself already rotates the display and things
look double-rotated, remove the --rot flag entirely. The .sh files are
plain text — edit over SSH with nano.

MISC
----
High scores save next to the binaries (survives reboots).
Music is George's original theme, synthesized at boot. N key would toggle
it on a keyboard; on the panel just use Batocera's volume.
Problems? Fill the form again at https://runningfrombears.ngrok.app/cabinet
with what happened, or text George.

DO NOT APPROACH THE BABY BEARS. SERIOUSLY.

V2 NOTES
--------
This build diagnoses itself. Just launch each game once from the PORTS
menu — even if the screen stays black and it dumps back to the menu,
the launcher writes /userdata/roms/ports/rfb/last_run.log, tries an
alternate video backend automatically, and uploads the log to George's
machine over WiFi. Launch it, wait ~15 seconds, done. George will see
exactly what happened.

V3 NOTES
--------
- IN-GAME QUIT: hold SELECT + START together for ~1 second.
- The game now uses the same video path as your emulators (SDL/KMSDRM),
  with the direct-DRM renderer as automatic fallback.
- The debug log uploads 15 seconds after launch AND after exit, so even
  a forced power-cycle can't eat the evidence.

V4 NOTES
--------
Root cause found: the menu (EmulationStation) never let go of the screen,
so the game ran invisibly. v4 stops the menu while playing and restarts
it when you quit (Select+Start held ~1s). Expect the menu to take a few
seconds to reappear after quitting — that's normal.

V10 NOTES (Nov 2026)
--------------------
- UPDATING IS NOW ONE BUTTON: PORTS -> "UpdateRunningFromBears" (WiFi on).
  Screen may sit dark ~20s, then the menu returns with the newest version.
  High scores are kept. Over SSH, same thing:
    curl -sL https://gcawood.github.io/running-from-bears/cabinet/install.sh | bash
- Bears now growl and huff as they close in (loudest when one circles your
  tree), cartoon yell + NOM NOM NOM when you get caught, and a TOK-oing!
  bonk + grumpy "HRMPH?!" + dizzy birdies when a pinecone lands.
- Bigger pinecone counter.
- Includes the v9 fixes: menu reliably comes back after quitting
  (Select+Start held ~1s), and the quit combo no longer pauses first.
