#!/bin/bash
# Detached runner (v10): stops EmulationStation (it hogs the display), runs
# the game, then restarts ES with verify-and-retry — a bare init "start"
# after an out-of-band stop silently no-ops (the v8 black-screen-on-exit).
#
# SDL backend FIRST: raylib's raw-DRM backend only understands modern
# gamepad button codes, and this cabinet's DragonRise encoder emits
# old-style joystick codes — buttons never arrive. The game bakes in the
# correct SDL mapping itself (env kept as belt-and-suspenders).
BIN="$1"
cd /userdata/roms/ports/rfb
LOG=/userdata/roms/ports/rfb/last_run.log
{ echo "=== RFB $BIN v10 $(date) ==="; uname -a; } > "$LOG"
( sleep 15; curl -s -m 10 -X POST --data-binary @"$LOG" https://runningfrombears.ngrok.app/cabinet/log >/dev/null 2>&1 ) &
sleep 1
/etc/init.d/S31emulationstation stop >> "$LOG" 2>&1
sleep 1
export SDL_VIDEODRIVER=kmsdrm
export SDL_GAMECONTROLLERCONFIG="03000000790000000600000010010000,DragonRise Inc. Generic USB Joystick,platform:Linux,a:b1,b:b0,x:b2,y:b3,start:b8,back:b10,guide:b9,leftx:a0,lefty:a1,"
S=$(date +%s)
"./${BIN}_sdl" --fs --size 1280x1024 --rot270 --loginfo --invx --invy >> "$LOG" 2>&1
if [ $(( $(date +%s) - S )) -lt 10 ]; then
    echo "=== SDL exited fast — DRM fallback (display only, buttons will not work) ===" >> "$LOG"
    "./$BIN" --fs --size 1280x1024 --rot270 --loginfo --invx --invy >> "$LOG" 2>&1
fi
{
    echo "=== bringing EmulationStation back ==="
    /etc/init.d/S31emulationstation start
    sleep 3
    if ! pgrep -f emulationstation >/dev/null; then
        echo "init start did not bring ES back — trying batocera-es-swissknife"
        batocera-es-swissknife --restart
        sleep 3
    fi
    if ! pgrep -f emulationstation >/dev/null; then
        echo "swissknife did not work either — trying init restart"
        /etc/init.d/S31emulationstation restart
        sleep 3
    fi
    echo "ES pid after restart attempts: $(pgrep -f emulationstation | head -1)"
} >> "$LOG" 2>&1
curl -s -m 10 -X POST --data-binary @"$LOG" https://runningfrombears.ngrok.app/cabinet/log >/dev/null 2>&1 || true
