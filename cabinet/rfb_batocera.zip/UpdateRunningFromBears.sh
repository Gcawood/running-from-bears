#!/bin/bash
# UPDATE RUNNING FROM BEARS — pick this from the PORTS menu (cabinet needs WiFi).
# Downloads the newest version from George's site and reinstalls it. The screen
# may go dark for ~20 seconds; the menu comes back with the new version.
exec bash -c "$(curl -sL "https://gcawood.github.io/running-from-bears/cabinet/install.sh?t=$(date +%s)")"
