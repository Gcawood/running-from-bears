#!/bin/bash
# RUNNING FROM BEARS — Classic flat edition (Batocera port, v10)
# In-game: hold SELECT+START ~1 second to quit (the menu restarts itself).
setsid /userdata/roms/ports/rfb/run_detached.sh bears >/dev/null 2>&1 &
exit 0
